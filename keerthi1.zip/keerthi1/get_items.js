function fetchItems() {
  fetch('get_items.jsp') // Replace with your server-side script that retrieves item data
    .then(response => response.json())
    .then(data => {
      // Call the function to update the HTML content with the fetched data
      updateItemContainer(data);
    })
    .catch(error => console.error(error));
}
function updateItemContainer(data) {
  const itemContainer = document.getElementById('itemContainer');
  
  // Clear the existing content
  itemContainer.innerHTML = '';

  // Loop through the fetched item data and create HTML elements
  data.forEach(item => {
    const itemElement = document.createElement('div');
    itemElement.classList.add('item');
    itemElement.innerHTML = `
      <img src="${item.photo}" alt="${item.name}" />
      <h3>${item.name}</h3>
      <p>Price: ${item.price}</p>
      <p>Category: ${item.category}</p>
    `;
    itemContainer.appendChild(itemElement);
  });
}
